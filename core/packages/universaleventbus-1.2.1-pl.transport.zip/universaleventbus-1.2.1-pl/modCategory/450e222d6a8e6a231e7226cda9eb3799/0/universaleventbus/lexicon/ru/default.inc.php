<?php

$_lang['area_ueb_switch'] = 'Переключатели';
$_lang['setting_ueb_debug'] = 'Включить отладку';
$_lang['setting_ueb_debug_desc'] = '';
$_lang['setting_ueb_cache'] = 'Использовать кэширование';
$_lang['setting_ueb_cache_desc'] = '';

$_lang['area_ueb_path'] = 'Пути';
$_lang['setting_ueb_sse_handler_path'] = 'Путь к серверному обработчику SSE.';
$_lang['setting_ueb_sse_handler_path_desc'] = '';
$_lang['setting_ueb_autoload_path'] = 'Путь к путь к автозагрузчику';
$_lang['setting_ueb_autoload_path_desc'] = '';
$_lang['setting_ueb_frontend_js'] = 'Путь к скриптам фронтенда.';
$_lang['setting_ueb_frontend_js_desc'] = '';
$_lang['setting_ueb_action_url'] = 'путь к коннектору';
$_lang['setting_ueb_action_url_desc'] = '';

$_lang['area_ueb_main'] = 'Основные настройки';
$_lang['setting_ueb_sse_retry'] = 'Частота опроса сервера';
$_lang['setting_ueb_sse_retry_desc'] = 'указывается в милисекундах.';
$_lang['setting_ueb_allowed_templates'] = 'Шаблоны в которых необходимо использовать шину событий';
$_lang['setting_ueb_allowed_templates_desc'] = 'если пусто, то во всех шаблонах';
$_lang['setting_ueb_open_classes'] = 'Список css-селекторов обозначающих открытый элемент';
$_lang['setting_ueb_open_classes_desc'] = 'через запятую';
$_lang['setting_ueb_close_classes'] = 'Список css-селекторов обозначающих закрытый элемент';
$_lang['setting_ueb_close_classes_desc'] = 'через запятую';
$_lang['setting_ueb_translit'] = 'Список ключей товара или заказа для транслитерации';
$_lang['setting_ueb_translit_desc'] = 'доступны: name, vendor, category, options.*, variant.*, variant.options.*';
