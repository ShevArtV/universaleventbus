--------------------
UniversalEventBus
--------------------
Author: Shevchenko Artur <shev.art.v@yandex.ru>
--------------------

UniversalEventBus - компонент для отправки серверных событий на фронт.

Возможности:
Компонент позволяет легче передавать данные в сервисы аналитики такие как Google Analytics, Yandex Metrika, Google Tag Manager, Facebook Pixel и другие.

--------------------
GitHub: https://github.com/ShevArtV/universaleventbus
