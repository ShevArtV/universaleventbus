<?php

namespace UniversalEventBus;


use UniversalEventBus\Helpers\Logging;
use UniversalEventBus\Helpers\QueueManager;
use UniversalEventBus\Helpers\EventStore;
use UniversalEventBus\Helpers\OrderAccess;
use Jaybizzle\CrawlerDetect\CrawlerDetect;

/**
 * @author Arthur Shevchenko (shev.art.v@yandex.ru)
 * @description Класс для передачи сервверных событий на фронт.
 */
class EventBus
{

    /**
     * @var \modX $modx
     */
    public \modX $modx;
    /**
     * @var Logging $logging
     */
    public Logging $logging;
    /**
     * @var QueueManager $queuemanager
     */
    public QueueManager $queuemanager;
    /**
     * @var EventStore $eventstore
     */
    public EventStore $eventstore;
    /**
     * @var \msoptionsprice|null $msop
     */
    protected ?\msoptionsprice $msop;
    /**
     * @var array|null $properties
     */
    private ?array $properties;
    /**
     * @var array $replacements
     */
    public array $replacements = [];
    /**
     * @var bool $isBot
     */
    public bool $isBot = false;
    /**
     * @var array $output
     */
    public array $output = [];
    /**
     * @var array|string[] $cacheOptions
     */
    private array $cacheOptions = [\xPDO::OPT_CACHE_KEY => 'eventbus'];
    /**
     * @var int $cacheExpireTime
     */
    private int $cacheExpireTime = 86400;
    /**
     * @var string $ctx
     */
    public string $ctx = 'web';
    /**
     * @var bool $debug
     */
    public bool $debug;
    /**
     * @var bool $useCache
     */
    private bool $useCache;
    /**
     * @var bool $dispatch
     */
    public bool $dispatch = true;
    /**
     * @var mixed $product
     */
    public array $product = [];
    /**
     * @var array $pageData
     */
    public array $pageData = [];
    /**
     * @var \miniShop2|null $miniShop2
     */
    public ?\miniShop2 $miniShop2 = null;
    /**
     * Id of the current page load: one per PHP request, shared by all instances.
     */
    private static string $pageId = '';
    /**
     * Stream position before this page published anything: a new tab starts here.
     */
    private static ?int $startCursor = null;
    /**
     * @var array $webConfig
     */
    public array $webConfig;
    /**
     * @var string $branch
     */
    public string $branch;
    /**
     * @var string $contextCookieName
     */
    public string $contextCookieName;
    /**
     * @var string $requestContextParam
     */
    private string $requestContextParam = 'ctx';

    /**
     * @var array $translit
     */
    private array $translit;
    /**
     * @var array $options
     */
    public array $options = [];
    /**
     * @var string $sessionId
     */
    public string $sessionId = '';

    /**
     * @param \modX $modx
     * @param array|null $properties
     */
    public function __construct(\modX $modx, ?array $properties = [])
    {
        $this->modx = $modx;
        $this->properties = $properties;
        $this->initialize();
    }

    /**
     * @return void
     */
    private function initialize()
    {
        $this->branch = !empty($this->properties['branch']) ? (string) $this->properties['branch'] : session_id();
        $this->debug = $this->modx->getOption('ueb_debug', null, true);
        $this->useCache = $this->modx->getOption('ueb_cache', null, true);
        $this->contextCookieName = $this->modx->getOption('ueb_context_cookie_name', null, 'ueb_context');
        $translit = $this->modx->getOption('ueb_translit', null, '');
        $this->translit = $translit ? explode(',', $translit) : [];
        $this->logging = new Logging($this->modx, $this->debug, $this->modx->getOption('ueb_log_level', null, 'error'));
        $this->logging->setProcess('universaleventbus_' . substr(md5((string) $this->branch), 0, 12));
        $this->queuemanager = new QueueManager($this->modx);
        $this->eventstore = new EventStore($this->modx);

        // SSE/cursor endpoints need the branch hooks, but not crawler detection,
        // miniShop2 or msOptionsPrice initialization.
        $onReading = !empty($this->properties['onReading']);
        if ($onReading) {
            $this->modx->invokeEvent('OnUebInit', [
                'branch' => $this->branch,
                'EventBus' => &$this
            ]);
            return;
        }

        $crawlerDetect = new CrawlerDetect;
        $this->isBot = $crawlerDetect->isCrawler();
        $this->msop = $this->setMsOptionPrice();
        $this->miniShop2 = $this->modx->getService('miniShop2');

        $this->modx->invokeEvent('OnUebInit', [
            'branch' => $this->branch,
            'EventBus' => &$this
        ]);
    }

    /**
     * @return object|null
     */
    private function setMsOptionPrice(): ?object
    {
        $corePath = $this->modx->getOption(
            'msoptionsprice_core_path',
            null,
            $this->modx->getOption('core_path', null, MODX_CORE_PATH) . 'components/msoptionsprice/'
        );

        $msoptionsprice = $this->modx->getService(
            'msoptionsprice',
            'msoptionsprice',
            $corePath . 'model/msoptionsprice/',
            array('core_path' => $corePath)
        );
        if (!$msoptionsprice) {
            return null;
        }
        $msoptionsprice->initialize($this->ctx, []);
        return $msoptionsprice;
    }

    /**
     * Кука контекста ставится на домен основного контекста, чтобы переключение
     * переживало переход между витринами: у мультидоменного сайта они часто
     * разведены по поддоменам одного домена.
     *
     * ⚠️ Домен берётся строкой: fetch(PDO::FETCH_COLUMN) возвращает значение
     * колонки, а не массив. Прежний `[0]` брал ПЕРВЫЙ СИМВОЛ этой строки, и
     * кука уходила на домен вида `s` — браузер её отбрасывал, а контекст
     * откатывался к дефолтному на каждом чужом поддомене.
     *
     * @return void
     */
    public function setContextCookie()
    {
        $expirationTime = time() + (30 * 24 * 60 * 60);
        $q = $this->modx->newQuery('modContextSetting');
        $q->select('value');
        $q->where(['key' => 'http_host', 'context_key' => 'web']);
        $host = $this->execute($this->getSQL($q), 'fetch', [\PDO::FETCH_COLUMN]);
        if (!is_string($host) || $host === '') {
            $host = $_SERVER['HTTP_HOST'];
        }

        // Домен основного контекста не обслуживает текущий запрос (витрины на
        // разных доменах, а не поддоменах) — кука остаётся на своём домене.
        if (strpos($_SERVER['HTTP_HOST'], $host) === false) {
            $host = $this->modx->getOption('http_host');
        }

        setcookie($this->contextCookieName, $this->modx->context->key, $expirationTime, '/', $host);
    }

    /**
     * Убирает из $modx->jscripts / $modx->loadedjscripts блоки UEB, пришедшие из кэша ресурса:
     * `window.uebConfig = ...` и тег модуля (адрес — по ueb_frontend_js без `?v=`).
     * Чужие скрипты не трогает.
     */
    protected function removeCachedScripts(string $indexJS): void
    {
        $configMarker = 'window.uebConfig =';
        $moduleBase = $indexJS !== '' ? explode('?', $indexJS, 2)[0] : '';
        $isOurs = static function ($src) use ($configMarker, $moduleBase) {
            if (!is_string($src)) {
                return false;
            }
            if (strpos($src, $configMarker) !== false) {
                return true;
            }
            return $moduleBase !== '' && strpos($src, '<script type="module" src="' . $moduleBase) !== false;
        };

        if (!empty($this->modx->jscripts) && is_array($this->modx->jscripts)) {
            $kept = array_filter($this->modx->jscripts, static function ($src) use ($isOurs) {
                return !$isOurs($src);
            });
            if (count($kept) !== count($this->modx->jscripts)) {
                // regClientScript пишет в jscripts[count()] — индексы должны быть последовательными
                $this->modx->jscripts = array_values($kept);
            }
        }
        if (!empty($this->modx->loadedjscripts) && is_array($this->modx->loadedjscripts)) {
            foreach (array_keys($this->modx->loadedjscripts) as $src) {
                if ($isOurs($src)) {
                    unset($this->modx->loadedjscripts[$src]);
                }
            }
        }
    }

    /**
     * @param int $templateId
     * @return void
     */
    public function loadJS(int $templateId)
    {
        $allowedTemplates = $this->modx->getOption('ueb_allowed_templates', null, '');
        $allowedTemplates = $allowedTemplates ? explode(',', $allowedTemplates) : [];
        if (!empty($allowedTemplates) && !in_array($templateId, $allowedTemplates)) {
            return;
        }

        $indexJS = $this->modx->getOption('ueb_frontend_js', '', '');
        $packageVersion = $this->getPackageVersion();
        $scriptsVersion = $packageVersion ? '?v=' . md5($packageVersion) : '';
        $openClasses = $this->modx->getOption('ueb_open_classes', '', '');
        $closeClasses = $this->modx->getOption('ueb_close_classes', '', '');
        //$scriptsVersion = '?v=' . time();

        $this->webConfig = [
            'version' => $scriptsVersion,
            'handlerPath' => $this->modx->getOption('ueb_sse_handler_path', '', '/assets/components/universaleventbus/php/ssehandler.php'),
            'actionUrl' => $this->modx->getOption('ueb_action_url', '', '/assets/components/universaleventbus/php/action.php'),
            'transport' => $this->modx->getOption('ueb_transport', null, 'adaptive'),
            'streamIdleTimeout' => (int) $this->modx->getOption('ueb_stream_idle_timeout', null, 30000),
            'cursorPollInitial' => (int) $this->modx->getOption('ueb_cursor_poll_initial', null, 2000),
            'cursorPollMax' => (int) $this->modx->getOption('ueb_cursor_poll_max', null, 30000),
            'navigationTimeout' => (int) $this->modx->getOption('ueb_navigation_timeout', null, 1200),
            'openClasses' => $openClasses ? explode(',', $openClasses) : [],
            'closeClasses' => $closeClasses ? explode(',', $closeClasses) : [],
            'pageId' => self::getPageId(),
            'startCursor' => $this->getStartCursor(),
        ];

        $this->modx->invokeEvent('OnGetUebWebConfig', [
            'webConfig' => $this->webConfig,
            'object' => $this
        ]);

        // Страница из кэша ресурса приносит с собой снимок блоков UEB (jscripts кэшируются) —
        // убираем его, чтобы остались только свежие конфиг (pageId, startCursor) и тег модуля.
        $this->removeCachedScripts((string) $indexJS);

        $webConfig = json_encode($this->webConfig, JSON_UNESCAPED_UNICODE);
        if ($indexJS) {
            $indexJS .= $scriptsVersion;
            $this->modx->regClientScript(
                "<script> window.uebConfig = {$webConfig}; </script>",
                1
            );
            $this->modx->regClientScript('<script type="module" src="' . $indexJS . '"></script>', 1);
        }
    }

    /**
     * @return string
     */
    private function getPackageVersion(): string
    {
        $q = $this->modx->newQuery('transport.modTransportPackage');
        $q->select('signature');
        $q->sortby('installed', 'DESC');
        $q->limit(1);
        $q->prepare();
        if (!$q->stmt->execute()) {
            return '';
        }
        return $q->stmt->fetchColumn();
    }

    private function getStartCursor(): int
    {
        if (self::$startCursor === null) {
            $legacy = $this->modx->getOption('ueb_transport', null, 'adaptive') === 'legacy';
            self::$startCursor = $legacy ? 0 : $this->eventstore->headCursor($this->branch);
        }
        return self::$startCursor;
    }

    /**
     * Key of the browser tab that sent the event from its page (UEB JS sendEvent).
     */
    private function getTabKey(): string
    {
        $tabKey = (string) ($this->properties['uebTabKey'] ?? '');
        return preg_match('/^[a-zA-Z0-9-]{8,64}$/', $tabKey) ? $tabKey : '';
    }

    public static function getPageId(): string
    {
        if (self::$pageId === '') {
            self::$pageId = bin2hex(random_bytes(8));
        }
        return self::$pageId;
    }

    /**
     * @param string $eventName
     * @return bool
     */
    public function handleEvent(string $eventName): bool
    {
        // Read before plugins below run: invokeEvent() rewrites modx->event.
        $isPageRender = ($this->modx->event->name ?? '') === 'OnLoadWebDocument';
        $this->ctx = $_COOKIE[$this->contextCookieName] ?: $_REQUEST[$this->requestContextParam] ?: $this->modx->context->get('key');
        if ($this->ctx && $this->ctx !== $this->modx->context->get('key') && $this->modx->getCount($this->ctx)) {
            $this->modx->switchContext($this->ctx);
        }

        if ($this->miniShop2 && !$this->miniShop2->initialized[$this->ctx]) {
            $this->miniShop2->initialize($this->ctx);
        }

        $this->modx->invokeEvent('OnBeforeUebHandleEvent', [
            'dispatch' => $this->dispatch,
            'EventBus' => &$this
        ]);

        if (($this->isBot && strpos($eventName,'OnChangeOrderStatus') === false) || !$this->dispatch) {
            return false;
        }

        $this->output = [
            'eventName' => $eventName,
            'eventTime' => time(),
            'eventId' => $this->getEventId($eventName),
            'userData' => [],
            'pageData' => $this->getPageData(),
            'orderData' => $this->getOrderData(),
            'cartData' => $this->getCartData(),
            'productsData' => [],
            'pushed' => []
        ];
        // Page render events belong to the tab with this page, not to whichever tab leads the bus.
        if ($isPageRender) {
            $this->getStartCursor();
            $this->output['pageId'] = self::getPageId();
        }
        // Events sent from a page belong to the tab that sent them.
        $tabKey = $this->getTabKey();
        if ($tabKey !== '') {
            $this->output['tabKey'] = $tabKey;
        }
        $this->output['userData'] = $this->getUserData($this->getUserId());
        $this->output['productsData'] = $this->getProductsData($eventName);

        if (empty($this->output['productsData']) && $this->output['pageData']['class_key'] === 'msProduct') {
            $this->output['productsData'] = [];
        }

        $this->modx->invokeEvent('OnUebHandleEvent', [
            'options' => $this->options,
            'output' => $this->output,
            'EventBus' => &$this
        ]);

        if ($this->dispatch) {
            $transport = $this->modx->getOption('ueb_transport', null, 'adaptive');
            if ($transport === 'legacy') {
                $this->queuemanager->addToQueue($this->branch, $this->output, $this->options);
            } else {
                $ttl = isset($this->options['ttl'])
                    ? (int) $this->options['ttl']
                    : (int) $this->modx->getOption('ueb_event_ttl', null, 300);
                if ($this->eventstore->publish($this->branch, $this->output, $ttl) === null) {
                    $this->dispatch = false;
                }
            }
        }
        return $this->dispatch;
    }

    /**
     * @return int
     */
    private function getUserId(): int
    {
        if(!empty($this->output['orderData'])) {
            return $this->output['orderData']['user_id'] ?: 0;
        }

        if ($this->modx->user->isAuthenticated($this->ctx)) {
            return $this->modx->user->id;
        }
        return $_SESSION['user_id'] ?? 0;
    }

    /**
     * @param string $eventName
     * @return string
     */
    public function getEventId(string $eventName): string
    {
        try {
            return bin2hex(random_bytes(16));
        } catch (\Throwable $exception) {
            return md5($eventName . microtime(true) . uniqid('', true));
        }
    }

    /**
     * @param int $userId
     * @return array
     */
    public function getUserData(int $userId): array
    {
        $userData = [
            'ip' => $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'],
            'userAgent' => $_SERVER['HTTP_USER_AGENT'],
            'referrer' => $_SERVER['HTTP_REFERER'],
            'id' => session_id(),
        ];

        $hash = md5($userId);
        if ($userId) {
            if ($this->useCache && $cached = $this->modx->cacheManager->get($hash, $this->cacheOptions)) {
                $userData = array_merge($userData, $cached);
                $this->modx->cacheManager->set($hash, $userData, $this->cacheExpireTime, $this->cacheOptions);
            } else {
                $q = $this->modx->newQuery('modUser');
                $q->leftJoin('modUserProfile', 'Profile');
                $q->select('modUser.username as username');
                $q->select($this->modx->getSelectColumns('modUserProfile', 'Profile'));
                $q->where([
                    'modUser.id' => $userId,
                ]);
                $userData = array_merge($userData, $this->execute($this->getSQL($q)));
            }
        }

        if(!empty($this->output['orderData'])){
            $address = [];
            foreach ($this->output['orderData'] as $key => $value) {
                if(strpos($key, 'address_') === false){
                    continue;
                }
                $key = str_replace('address_', '', $key);
                $address[$key] = $value;
            }
            $userData = array_merge($userData, $address);
        }

        return $this->filterArray($userData);
    }

    /**
     * @return array
     */
    public function getPageData(): array
    {
        if (!$where = $this->getConditionsForGetResourceData()) {
            $this->dispatch = false;
            return [];
        }

        $resourceData = $this->getResourceData($where);

        $this->dispatch = isset($resourceData['id']);
        if ($this->msop && $resourceData['class_key'] === 'msProduct') {
            $resourceData['modification'] = (int)$_REQUEST['mid'];
            $resourceData['options'] = [];
            if ($_REQUEST['options']) {
                $resourceData['options'] = is_array($_REQUEST['options']) ? $_REQUEST['options'] : json_decode($_REQUEST['options'], true);
            }
            $resourceData['variant'] = $this->getProductVariant($resourceData);
            $resourceData['price'] = $this->getShowPrice($resourceData);
        }

        $this->pageData = $resourceData;
        $this->modx->invokeEvent('OnUebGetPageData', [
            'pageData' => $this->pageData,
            'EventBus' => &$this
        ]);

        return $this->filterArray($this->pageData);
    }

    /**
     * @return array
     */
    private function getConditionsForGetResourceData(): array
    {
        $extension = explode('?', $_SERVER['REQUEST_URI'])[0];
        $extension = pathinfo($extension, PATHINFO_EXTENSION);

        if (isset($this->properties['rid'])) {
            return [
                'id' => $this->properties['rid']
            ];
        } elseif (isset($this->properties['uri'])) {
            $uri = ltrim($this->properties['uri'], '/');
            return [
                'uri' => $uri,
                'context_key' => $this->ctx
            ];
        } elseif ($this->modx->resource && in_array($extension, ['html', ''])) {
            return [
                'id' => $this->modx->resource->id
            ];
        } elseif ($extension === 'php') {
            $uri = parse_url($_SERVER['HTTP_REFERER']);
            $uri = $uri['path'];
            $uri = ltrim($uri, '/');
            if (!$uri) {
                return [
                    'id' => $this->modx->getContext($this->ctx)->getOption('site_start')
                ];
            }
            return [
                'uri' => $uri,
                'context_key' => $this->ctx
            ];
        }

        return [];
    }

    /**
     * @param array $where
     * @param string|null $fetchMethod
     * @return array
     */

    public function getResourceData(array $where, ?string $fetchMethod = 'fetch'): array
    {
        $hash = md5(json_encode($where));
        if ($this->useCache && $output = $this->modx->cacheManager->get($hash, $this->cacheOptions)) {
            return $output;
        }

        $q = $this->modx->newQuery('modResource');
        $q->select($this->modx->getSelectColumns('modResource', 'modResource'));
        $q->leftJoin('modResource', 'Category', 'modResource.parent = Category.id');
        $q->select('Category.pagetitle as category');
        if ($this->miniShop2 instanceof \miniShop2) {
            $q->leftJoin('msProductData', 'Data', 'modResource.id = Data.id');
            $q->select($this->modx->getSelectColumns('msProductData', 'Data', '', ['id'], true));
            $q->leftJoin('msVendor', 'Vendor', 'Data.vendor = Vendor.id');
            $q->select($this->modx->getSelectColumns('msVendor', 'Vendor', 'vendor_'));
        }
        $q->where($where);
        if ($output = $this->execute($this->getSQL($q), $fetchMethod)) {
            if ($fetchMethod === 'fetchAll') {
                foreach ($output as $k => $v) {
                    $output[$k]['url'] = $this->modx->makeUrl($v['id'], $this->ctx, '', 'full');
                }
            } else {
                $output['url'] = $this->modx->makeUrl($output['id'], $this->ctx, '', 'full');
            }

            $this->modx->cacheManager->set($hash, $output, $this->cacheExpireTime, $this->cacheOptions);
            if ($this->debug && $this->sessionId === session_id()) {
                $this->logging->write(__METHOD__ . ':' . __LINE__, 'resourceData: ', $output, false, 'debug', 'events');
            }
            return $output;
        }
        return [];
    }

    /**
     * @return array
     */
    public function getOrderData(): array
    {
        if (!($this->miniShop2 instanceof \miniShop2)) {
            return [];
        }
        $orderId = $this->getOrderId();
        if (!$orderId) {
            return $this->miniShop2->order->get() ?: [];
        }

        $q = $this->modx->newQuery('msOrder');
        $q->leftJoin('msOrderAddress', 'Address');
        $q->leftJoin('msDelivery', 'Delivery', 'Delivery.id = msOrder.delivery');
        $q->leftJoin('msPayment', 'Payment', 'Payment.id = msOrder.payment');
        $q->select($this->modx->getSelectColumns('msOrder', 'msOrder'));
        $q->select($this->modx->getSelectColumns('msOrderAddress', 'Address', 'address_'));
        $q->select($this->modx->getSelectColumns('msDelivery', 'Delivery', 'delivery_'));
        $q->select($this->modx->getSelectColumns('msPayment', 'Payment', 'payment_'));
        $q->where(['msOrder.id' => $orderId]);
        $orderData = $this->execute($this->getSQL($q));
        if ($this->debug && $this->sessionId === session_id()) {
            $this->logging->write(__METHOD__ . ':' . __LINE__, 'orderData: ', $orderData, false, 'debug', ['events', 'order']);
        }
        foreach ($orderData as $k => $v) {
            if(strpos($k, 'properties') !== false && !is_array($v)) {
                $orderData[$k] = json_decode($v, true);
            }
        }

        $orderData = $this->translitArray($orderData);
        return $this->filterArray($orderData);
    }

    /**
     * Изменение позиции считается сравнением актуальной корзины со снимком
     * предыдущего события.
     *
     * ⚠️ Позицию, удалённую целиком, в актуальной корзине уже нет: её поля
     * приходится брать из снимка. Прежний код на этом и сравнивал снимок сам с
     * собой — количество после удаления получалось равным количеству до него,
     * `count_diff` выходил нулём, а `count_change` пустым. Потребители видели
     * «ничего не изменилось» на полном удалении позиции.
     *
     * @return array
     */
    public function getCartData(): array
    {
        if (!($this->miniShop2 instanceof \miniShop2)) {
            return [];
        }
        $key = $this->properties['key'] ?? '';
        $cart = $this->miniShop2->cart->get();
        $snapshot = $_SESSION['ueb']['cart'][$key] ?? [];
        $item = $cart[$key] ?? $snapshot;

        $oldCount = (int) ($snapshot['count'] ?? 0);
        // Ключа нет в актуальной корзине — позиция удалена целиком, количество после
        // изменения равно нулю. Поля самого $item остаются снимком: их читает
        // getProductData() как данные товара, к которому относится событие.
        $newCount = isset($cart[$key]) ? (int) $item['count'] : 0;

        $item['count_change'] = '';
        if ($newCount < $oldCount) {
            $item['count_change'] = 'remove';
        } elseif ($newCount > $oldCount) {
            $item['count_change'] = 'add';
        }
        $item['count_diff'] = abs($newCount - $oldCount);

        $_SESSION['ueb']['cart'] = $cart;
        return [
            'products' => $cart,
            'status' => $this->miniShop2->cart->status(),
            'item' => $item
        ];
    }

    /**
     * @return int
     */
    private function getOrderId(): int
    {
        // Id из запроса (и сессионный msorder, который туда пишут проекты) — только свой заказ;
        // orderId ставит плагин пакета при оформлении в сессии покупателя.
        $orderId = (int)($_REQUEST['msorder'] ?? 0) ?: (int)($_SESSION['ueb']['msorder'] ?? 0);
        if ($orderId && !(new OrderAccess($this->modx))->isOwned($orderId)) {
            $orderId = 0;
        }
        $orderId = $orderId ?: (int)($_SESSION['ueb']['orderId'] ?? 0);
        $msOrder = $this->properties['msOrder'] ?: $this->properties['order'];

        if ($msOrder instanceof \msOrder) {
            $orderId = $msOrder->get('id');
        }
        if ($msOrder instanceof \msOrderHandler) {
            $orderData = $msOrder->get();
            $orderId = $orderData['id'];
        }
        return $orderId ?: 0;
    }

    /**
     * @param $eventName
     * @return array
     */
    public function getProductsData($eventName): array
    {
        if (!($this->miniShop2 instanceof \miniShop2)) {
            return [];
        }
        $output = [];

        if ($_REQUEST['ids']) {
            $ids = explode(',', $_REQUEST['ids']);

            foreach ($ids as $id) {
                $options = [];
                if ($_REQUEST['options']) {
                    $options = is_array($_REQUEST['options']) ? $_REQUEST['options'] : json_decode($_REQUEST['options'], true);
                }
                $output[] = $this->getProductData([
                    'product_id' => $id,
                    'options' => $options[$id] ?? [],
                    'mid' => $_REQUEST[$id]['mid'] ?: 0
                ]);
            }
            return $output;
        }

        $orderId = $this->getOrderId();
        if (!$orderId) {
            if (strpos($eventName, 'Cart') === false) {
                return [];
            }
            if($this->properties['key']){
                $output[] = $this->getProductData($this->output['cartData']['item']);
            }else{
                $cart = $this->miniShop2->cart->get();
                foreach ($cart as $product) {
                    $output[] = $this->getProductData($product);
                }
            }

        } else {
            $q = $this->modx->newQuery('msOrderProduct');
            $q->select($this->modx->getSelectColumns('msOrderProduct', 'msOrderProduct'));
            $q->where(['msOrderProduct.order_id' => $orderId]);
            $products = $this->execute($this->getSQL($q), 'fetchAll');
            foreach ($products as $product) {
                unset($product['id']);
                $product['options'] = json_decode($product['options'], true);
                $output[] = $this->getProductData($product);
            }
        }

        return $output;
    }

    /**
     * @param array $product
     * @return array
     */
    public function getProductData(array $product): array
    {
        $hasOwnPrice = isset($product['price']);
        $data = $this->getResourceData(['id' => ($product['product_id'] ?: $product['id'])]);
        $product = array_merge($data, $product);

        if ($this->msop && empty($product['variant'])) {
            $product['variant'] = $this->getProductVariant($product);
        }

        // Позиция корзины и позиция заказа приносят свою цену — она уже учитывает
        // модификацию и скидки, пересчитывать её нельзя. Ветки, собранные из ресурса
        // (листинг по $_REQUEST['ids'], вызовы getProductData() снаружи), цены не
        // приносят вовсе и получают из msProductData цену товара, а не цену показа.
        if ($this->msop && !$hasOwnPrice && $product['class_key'] === 'msProduct') {
            $product['price'] = $this->getShowPrice($product);
        }

        $product['cost'] = $product['price'] * $product['count'];

        $this->product = [
            'id' => $product['id'],
            'name' => $product['pagetitle'],
            'price' => $product['price'],
            'quantity' => $product['count'],
            'weight' => $product['weight'],
            'cost' => $product['cost'],
            'url' => $product['url'],
            'brand' => $product['vendor_name'],
            'category' => $product['category'],
            'options' => $product['options'],
            'variant' => $product['variant'],
            'position' => $product['menuindex'],
            'list' => $product['category'],
            'count_diff' => $product['count_diff'],
        ];

        $this->modx->invokeEvent('OnUebGetProductData', [
            'product' => $this->product,
            'EventBus' => &$this
        ]);

        $product = $this->translitArray($this->product);

        return $this->filterArray($product);
    }

    public function getProductVariant(array $product): array
    {
        $output = [];
        if ($modificationId = $this->getModificationId($product)) {
            $output = $this->getModificationById($modificationId);
        } elseif (isset($product['options'])) {
            $output = $this->getModificationByOptions($product);
        }
        return $this->filterArray($output);
    }

    /**
     * Идентификатор выбранной модификации из данных товара.
     *
     * Ключ `mid` читается наравне с `modification`: getProductsData() кладёт во
     * входной массив именно его ($_REQUEST[<id>]['mid'] у карточки листинга), и
     * раньше выбранная в листинге модификация здесь терялась.
     *
     * @param array $product
     * @return int
     */
    public function getModificationId(array $product): int
    {
        return (int)($product['options']['modification'] ?? 0)
            ?: (int)($product['modification'] ?? 0)
            ?: (int)($product['mid'] ?? 0);
    }

    /**
     * Цена показа товара — та, которую покупатель видит в карточке и в листинге.
     *
     * Правило расчёта целиком принадлежит msOptionsPrice: getCostByModification()
     * применяет тип модификации (абсолютная цена, надбавка, скидка, процент),
     * учитывает настройку msoptionsprice_allow_zero_cost и по пути зовёт события
     * msopOnBeforeGetCost/msopOnAfterGetCost, поэтому чужие наценки и скидки не
     * теряются. Здесь только выбор модификации: выбрана — считаем по ней, не
     * выбрана — берём минимум по активным, модификаций нет — цена товара.
     *
     * $isAjax = false отдаёт число, а не отформатированную строку вида "119.00":
     * цена уходит в дата-слой аналитики, где строка ломает арифметику.
     *
     * @param array $product данные ресурса (modResource + msProductData)
     * @return float
     */
    public function getShowPrice(array $product): float
    {
        $price = (float)$product['price'];
        $productId = (int)($product['product_id'] ?: $product['id']);
        if (!$this->msop || !$productId) {
            return $price;
        }

        // Подбор по опциям — только когда опции пришли выбором покупателя, то есть
        // массивом. У msProductData есть собственное поле options со ВСЕМИ опциями
        // товара строкой JSON; подбор по нему возвращает произвольную модификацию,
        // и цена показа получилась бы случайной.
        if ($modificationId = $this->getModificationId($product)) {
            $modification = $this->getModificationById($modificationId);
        } elseif (!empty($product['options']) && is_array($product['options'])) {
            $modification = $this->getModificationByOptions($product);
        } else {
            $modification = [];
        }

        if ($modification) {
            return $this->getCostByModification($productId, $price, $modification);
        }

        $prices = [];
        foreach ($this->getActiveModifications($productId) as $activeModification) {
            $prices[] = $this->getCostByModification($productId, $price, $activeModification);
        }
        if (!$prices) {
            return $price;
        }

        // Нулевая цена модификации — это либо распроданный вариант, либо незаполненная
        // карточка: показывать её как цену товара нечестно, поэтому минимум берётся
        // среди положительных. Все нули — отдавать нечего, возвращаем как есть.
        $positive = array_filter($prices, function ($cost) {
            return $cost > 0;
        });

        return $positive ? min($positive) : min($prices);
    }

    /**
     * @param int $productId
     * @param float $price
     * @param array $modification
     * @return float
     */
    private function getCostByModification(int $productId, float $price, array $modification): float
    {
        $cost = $this->msop->getCostByModification($productId, $price, $modification, false);

        // msopOnBeforeGetCost/msopOnAfterGetCost могут отбить расчёт — тогда метод
        // возвращает не число, а текст ошибки. Цена товара честнее нуля.
        return is_numeric($cost) ? (float)$cost : $price;
    }

    /**
     * Активные модификации товара.
     *
     * Без кэша осознанно: цена и активность модификации меняются чаще, чем
     * сбрасывается кэш пакета, а выборка идёт по индексу rid.
     *
     * @param int $productId
     * @return array
     */
    public function getActiveModifications(int $productId): array
    {
        $q = $this->modx->newQuery('msopModification');
        $q->select($this->modx->getSelectColumns('msopModification', 'msopModification'));
        $q->where([
            'rid' => $productId,
            'active' => 1
        ]);
        return $this->execute($this->getSQL($q), 'fetchAll') ?: [];
    }

    /**
     * @param int $id
     * @return array
     */
    public function getModificationById(int $id): array
    {
        $hash = md5('msopModification' . $id);
        if ($this->useCache && $output = $this->modx->cacheManager->get($hash, $this->cacheOptions)) {
            return $output;
        }
        $q = $this->modx->newQuery('msopModification');
        $q->select($this->modx->getSelectColumns('msopModification', 'msopModification'));
        $q->where(['id' => $id]);
        if ($output = $this->execute($this->getSQL($q))) {
            $this->modx->cacheManager->set($hash, $output, $this->cacheExpireTime, $this->cacheOptions);
            return $output;
        }

        return [];
    }

    /**
     * @param array $data
     * @return array
     */
    public function getModificationByOptions(array $data): array
    {
        if (!$this->msop) {
            return [];
        }
        $productId = $data['product_id'] ?: $data['id'];
        $hash = md5(strtolower($productId . serialize($data['options'])));
        if ($this->useCache && $output = $this->modx->cacheManager->get($hash, $this->cacheOptions)) {
            return $output;
        }
        $excludeIds = array(0);
        $excludeType = array(0, 2, 3);
        if (!is_array($data['options'])) {
            $data['options'] = json_decode($data['options'], true);
        }
        if (!$modification = $this->msop->getModificationByOptions($productId, $data['options'], null, $excludeIds, $excludeType)) {
            return [];
        }

        $this->modx->cacheManager->set($hash, $modification, $this->cacheExpireTime, $this->cacheOptions);
        return $modification;
    }

    /**
     * @param string|null $string
     * @return string
     */
    public function getTranslitString(?string $string): string
    {
        if (!$string) {
            return '';
        }

        $r = $this->modx->newObject('modResource');
        $string = $r->cleanAlias($string);
        unset($r);
        return $string;
    }

    /**
     * @param string $sql
     * @param string|null $method
     * @param array $fetchType
     * @return array|string
     */
    public function execute(string $sql, ?string $method = 'fetch', array $fetchType = [\PDO::FETCH_ASSOC])
    {
        $tstart = microtime(true);
        $sql = preg_replace('/^SELECT/', 'SELECT SQL_CALC_FOUND_ROWS', $sql);
        $stmt = $this->modx->prepare($sql);
        if ($stmt->execute()) {
            $this->modx->queryTime += microtime(true) - $tstart;
            $this->modx->executedQueries++;
            return $stmt->$method(implode('|', $fetchType)) ?: [];
        }
        return [];
    }

    /**
     * @param \xPDOQuery $q
     * @return string
     */
    public function getSQL(\xPDOQuery $q): string
    {
        $q->prepare();
        $sql = $q->toSQL();
        $sql = str_replace('``,', '', $sql);

        if (!empty($this->replacements)) {
            foreach ($this->replacements as $k => $v) {
                $sql = str_replace($k, $v, $sql);
            }
            $this->replacements = [];
        }
        if ($this->debug && $this->sessionId === session_id()) {
            $this->logging->write(__METHOD__ . ':' . __LINE__, 'SQL: '. $sql, [], false, 'debug', 'events');
        }
        return $sql;
    }

    /**
     * @param array $array
     * @return array
     */
    public function filterArray(array $array): array
    {
        if (empty($array)) {
            return [];
        }
        return array_diff($array, [null, false, '', 0]);
    }

    /**
     * @param array $array
     * @return array
     */
    public function translitArray(array $array):array {
        if(empty($this->translit) || empty($array)) {
            return $array;
        }

        foreach ($this->translit as $key) {
            $path = explode('.', $key);
            $target = &$array;

            foreach ($path as $segment) {
                $target = &$target[$segment];
            }

            $target = $this->getTranslitString($target);
            unset($target);
        }

        return $array;
    }

    /**
     * @return void
     */
    public function cleanCache(): void
    {
        $this->modx->cacheManager->clean($this->cacheOptions);
    }
}
