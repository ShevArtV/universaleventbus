<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '1.3.5-rc
==============
- SECURITY: данные заказа отдаются только его покупателю. getOrderId() брал id заказа из
  $_REQUEST[\'msorder\'] без проверки, поэтому POST в action.php с msorder=N отдавал в шину
  адрес, контакты, доставку, оплату и состав чужого заказа. Теперь id из запроса и из
  $_SESSION[\'ueb\'][\'msorder\'] принимается, только если заказ в сессии miniShop2
  (minishop2.orders), принадлежит авторизованному пользователю (user_id > 0) или открыта
  сессия mgr; иначе данные заказа не подставляются, попытка пишется в журнал (WARN).
  Заказ из свойств события (msOrder/order: смена статуса, вебхуки) и
  $_SESSION[\'ueb\'][\'orderId\'] от плагина пакета проверка не затрагивает.

1.3.4-rc
==============
- FIX: полное удаление позиции из корзины сообщалось как «ничего не изменилось».
  getCartData() определяет изменение сравнением актуальной корзины со снимком
  предыдущего события, но удалённой позиции в актуальной корзине уже нет — её поля
  брались из снимка, и снимок сравнивался сам с собой. Количество после удаления
  выходило равным количеству до него: count_diff = 0, count_change = \'\'. Потребители
  (аналитика корзины) получали удалённое количество из fallback\'а — как правило единицу
  вместо фактических четырёх. Теперь отсутствие ключа в корзине считается нулевым
  количеством: count_diff равен удалённому количеству, count_change = \'remove\'.
  Уменьшение количества и добавление товара считаются как раньше.

1.3.3-rc
==============
- FIX: в данные товара уходит цена показа, а не цена ресурса из msProductData. Там, где
  товар собирается из ресурса (листинг по $_REQUEST[\'ids\'], вызовы getProductData() без
  своей цены, данные страницы товара), шина отдавала msProductData.price — цену, которую
  покупатель на витрине не видит, если у товара есть модификации msOptionsPrice. Аналитика
  из-за этого считала выручку по несуществующей цене: view_item и select_item расходились
  с add_to_cart на том же товаре. Цену считает сам msOptionsPrice методом
  getCostByModification(): выбрана модификация — по ней, не выбрана — минимум по активным,
  модификаций нет — цена товара. Позиции корзины и заказа приносят собственную цену и
  пересчёту не подлежат.
- FIX: выбранная в листинге модификация больше не теряется. getProductsData() кладёт её
  идентификатор в ключ mid, а getProductVariant() читал только modification и options —
  вариант приходил пустым, хотя фронт модификацию передал.
- FEATURE: событие OnUebGetPageData ($pageData, $EventBus) — точка, где плагин может
  дополнить или изменить данные страницы ($EventBus->pageData). Раньше данные страницы
  были недоступны для правки: OnUebHandleEvent отдаёт каждому плагину свою копию output,
  а единственная точка над товаром, OnUebGetProductData, на странице товара не вызывается.

1.3.2-rc
==============
- FIX: пакет регистрирует событие OnUebGetProductData. Раньше этого имени не было в
  modx_system_eventnames, поэтому подписка на него не работала и не давала следа в
  логах: карта событий MODX строится через INNER JOIN по зарегистрированным именам,
  и плагин с незарегистрированным событием просто не вызывается.
- FIX: имя события в readme исправлено на OnUebGetProductData — документация
  описывала его как OnUebGetProductsData, хотя такого события в шине нет.
- BUILD: список системных событий задан в сборщике пакета, а не выбирается из базы
  стенда сборки. Раньше в пакет уезжали те имена, которые были заведены в админке
  стенда, из-за чего событие, добавленное в код, могло не попасть в реестр.

1.3.1-rc
==============
- FIX: кука контекста снова ставится на домен основного контекста, а не на его первый
  символ. fetch(PDO::FETCH_COLUMN) возвращает значение колонки строкой, а обращение [0]
  брало из неё первый символ: setContextCookie отправлял домен вида "s", браузер такую
  куку отбрасывал. На сайтах, где витрины разведены по поддоменам одного домена, контекст
  из-за этого не переживал переход на соседний поддомен и откатывался к основному —
  вместе с языком и site_url. На однодоменных сайтах дефект не проявлялся.

1.3.0-rc
==============
- FEATURE: adaptive local transport без внешних сервисов. Активная вкладка держит bounded
  SSE с heartbeat, после idle переходит на короткий cursor polling с backoff, скрытая
  вкладка не держит PHP worker. BroadcastChannel оставляет один transport на browser profile.
- FEATURE: события хранятся до TTL в локальной таблице <prefix>ueb_events с cursor и UUID;
  SSE освобождает PHP session lock до цикла. Событие не удаляется при первом чтении, поэтому
  новая страница или вкладка может дочитать его до TTL.
- FIX: click по обычной ссылке с data-ueb-event ждёт запись события не дольше
  ueb_navigation_timeout и перед переходом останавливает transport текущей страницы.
  Это устраняет гонку отменённого fetch при выгрузке документа.

1.2.6-pl
==============
- FIX: keepalive у fetch-запросов eventbus.js включается только по явному флагу
  (paramsObj.keepalive / data-ueb-params / config.keepalive) либо когда страница уже
  скрывается (visibilityState=hidden). Раньше keepalive:true стоял на всех запросах:
  по спецификации Fetch суммарное тело всех keepalive-запросов страницы ограничено
  64 КБ, превышение давало TypeError: Failed to fetch и терялись события.

1.2.5-pl
==============
- Логирование переведено с файлов (logs/*.txt) на mxLogger. Хелпер Logging делегирует
  записи сервису mxLogger (если установлен), иначе молчит и один раз предупреждает в
  журнале MODX. Перевод затронул EventBus и QueueManager.
- Гейты: ueb_debug (вкл/выкл) + новая настройка ueb_log_level (минимальный уровень
  debug|info|warning|error, по умолчанию error; единый приёмник mxLogger, включено из коробки). Консистентно с mxLogger.min_level.
  QueueManager теперь учитывает ueb_debug (раньше new Logging() без гейта).
- Тэги: базовые universaleventbus + events, этапные order (orderData), queue (очередь).
  Воронка process_uid = «universaleventbus_»+md5(branch) — события одной сессии/ветки
  склеиваются в mxLogger одним процессом.
- Сигнатура Logging::write сохранена (позиционные method/msg/data), добавлены параметры
  $level и $tags. Уровни: дампы resourceData/orderData/SQL — debug; пустая ветка/данные
  очереди — warning.
- ВНИМАНИЕ: перед сборкой настройку ueb_log_level создать в менеджере (namespace
  universaleventbus) — сборка тянет настройки из БД стенда.

1.2.4-pl
==============
- Вынес contextCookieName в системные настройки (ueb_context_cookie_name).
- Добавил проверку существования контекста перед переключением.

1.2.3-pl
==============
- Исправление ошибок.

1.2.2-pl
==============
- Исправление ошибок.

1.2.1-pl
==============
- Добавил возможность явно передать контекст в метод handleEvent().

1.2.0-pl
==============
- Мелкие правки.

1.2.0-beta7
==============
- Изменил логику смены контекста.
- Добавил систему гарантированной доставки сообщений.
- Добавил в ответ при отправке браузерного события информацию о добавлении события в очередь.
- Оптимизировал работу компонент при нескольких открытых вкладках.
- Поменял доступность свойства EventBus::contextCookieName.

1.2.0-beta6
==============
- Поместил создание экземпляра класса EventBus в метод обработчик события DOMContentLoaded.

1.2.0-beta5
==============
- Сделал свойство EventBus::isBot публичным.

1.2.0-beta4
==============
- Исправил ошибку в методе execute() при возврате строки.
- Добавил возможность передавать в менеджер очередей опции при добавлении элемента в очередь.

1.2.0-beta3
==============
- Исправил получение данных о конкретном элементе корзины.

1.2.0-beta2
==============
- Добавил возможность транслитерации полей товара в orderData.
- Изменил обработку открытий и закрытий элементов.

1.2.0-beta
==============
- Добавил возможность транслитерации полей товара в productsData.
- Добавил получение данных модификации при использовании msOptionsPrice2.

1.1.0-beta4
==============
- Мелкие правки.

1.1.0-beta3
==============
- Добавил возможность использовать методы execute() и getSQL().
- Добавил возможность определять страницу по переданному в параметрах uri.

1.1.0-beta2
==============
- Добавил возможность пересылать сообщения между пользователями.
- Добавил возможность программно отправлять события на сервер.

1.1.0-beta
==============
- Добавил отправку браузерных событий на сервер.

1.0.0-beta2
==============
- Добавил ESLint.
- Добавил информацию о корзине.
- Поменял приоритет для события OnLoadWebDocument.
- Убрал любые манипуляции с данными на фронтенде.

1.0.0-beta
==============
- Первая сборка.
',
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
UniversalEventBus
--------------------
Author: Shevchenko Artur <shev.art.v@yandex.ru>
--------------------

UniversalEventBus - компонент для отправки серверных событий на фронт и событий фронта на сервер.

Транспорт server→browser работает полностью на текущем MODX-сервере, без внешних
realtime-сервисов. В режиме adaptive активная вкладка держит ограниченное по времени
SSE-соединение, после периода бездействия закрывает его и переходит на короткие cursor-запросы
с увеличивающимся интервалом. Скрытая вкладка запросов не выполняет. При активности или
получении события SSE открывается снова. Несколько вкладок используют один сетевой transport
через BroadcastChannel.

Cursor-события хранятся с TTL в локальной таблице <prefix>ueb_events. PHP-сессия закрывается
до начала SSE-цикла и не блокирует корзину, checkout и другие AJAX-запросы.
Событие не удаляется при первом подтверждении cursor: до истечения TTL его может дочитать
следующая страница или вкладка, которая ещё не сохранила cursor лидирующей вкладки.

Как пользоваться:
1. Создать в админке плагин с любым именем и подключить его к нужным событиям.
<code>
use UniversalEventBus\\EventBus;

$basePath = $modx->getOption(\'base_path\', null, $_SERVER[\'DOCUMENT_ROOT\'] . \'/\');
require_once $basePath . \'core/components/universaleventbus/services/vendor/autoload.php\';

$eventBus = new EventBus($modx);
$eventBus->handleEvent($modx->event->name);
</code>

2. В JavaScript нужно ловить событие "eventbus" и в обработчике выполнять необходимое действие.
<code>
document.addEventListener(\'eventbus\', (event) => {
    console.log(event.detail.data);
});
</code>

3. Вы можете передавать на сервер информацию о браузерных событиях. Например, для передачи на сервер информации о клике по ссылке
<code>
<a href="{$uri}" data-ueb-event="click" data-ueb-once="1" data-ueb-params="rid:{$id};eventName:productClick">{$menutitle}</a>
</code>
Атрибут data-ueb-once указывает на то, что событие будет отправлено только один раз.

Доступны нестандартные значения для атрибута data-ueb-event:
- close/open - установите его элементам которые должны закрыться/открыться
- show/hide - установите его элементам которые должны появляться/исчезать (например при скролле)
При использовании событий close/open у целевых элементов должны меняться классы отвечающие за показ/скрытие
 и эти классы надо перечислить в системных настройках.

В атрибуте data-ueb-params можно указать произвольные параметры, которые будут переданы в событие на сервер.

4. Вы можете добавить обработчик события eventbus:before:send и добавить любые данные для передачи на сервер
<code>
    document.addEventListener(\'eventbus:before:send\', (event) => {
       const {target, params} = event.detail;
       if(target.id === \'#product-1\') {
            params.append(\'product_id\', 1);
       }
    });
</code>

Системные события:
- OnUebInit (после инициализации компонента): $EventBus
- OnBeforeUebHandleEvent (перед получением данные и добавления в очередь): $EventBus, $dispatch
- OnUebHandleEvent (после получения данных, но перед добавлением в очередь): $output, $EventBus
- OnUebGetProductData (получение данных о товаре): $product, $EventBus.
- OnUebGetPageData (получение данных о странице): $pageData, $EventBus.
- OnGetUebWebConfig (получение конфигурации фронтенда): $webConfig, $EventBus.

Вы можете отменить добавление события в очередь в плагине: $EventBus->dispatch = false.
Вы можете изменить данные перед отправкой в очередь в плагине: $EventBus->output = [];
Вы можете изменить данные товара в плагине: $EventBus->product = [];
Вы можете изменить данные страницы в плагине: $EventBus->pageData = [];
Вы можете изменить конфигурации фронтенда в плагине: $EventBus->webConfig = [];
Вы можете изменить получателя в плагине: $EventBus->branch = \'branch_name\';
Вы можете изменить получателя при инициализации: $EventBus = new EventBus($modx, [\'branch\' => \'branch_name\']);

Основные настройки adaptive transport:
- ueb_transport: adaptive или legacy;
- ueb_stream_duration: максимальная длительность одного SSE-запроса, секунды;
- ueb_stream_heartbeat: интервал heartbeat, секунды;
- ueb_stream_read_interval: интервал проверки EventStore внутри SSE, миллисекунды;
- ueb_stream_idle_timeout: таймаут перехода активной вкладки в cursor polling, миллисекунды;
- ueb_cursor_poll_initial / ueb_cursor_poll_max: границы backoff cursor polling, миллисекунды;
- ueb_event_ttl: срок хранения недоставленного события, секунды;
- ueb_event_batch_size: максимум событий за одно чтение;
- ueb_navigation_timeout: максимальная задержка перехода по обычной ссылке, пока браузерное событие записывается на сервер, миллисекунды.

Для обычного клика по ссылке с data-ueb-event="click" переход выполняется после ответа
action.php либо по истечении ueb_navigation_timeout. Это закрывает гонку, при которой браузер
мог отменить fetch во время выгрузки страницы. Перед отправкой текущая страница закрывает
свой transport, поэтому событие дочитывает уже следующая страница. Ссылки с модификаторами,
download, target не равным _self и переходы только по hash не задерживаются.

Для того, чтобы в данных была информация о модификациях, нужно передать на сервер id модификации в параметре mid
или опции в параметре options, по которым можно получить модификацию.

--------------------
GitHub: https://github.com/ShevArtV/universaleventbus
',
    'setup-options' => 'universaleventbus-1.3.5-rc/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9710df671f188b4c62d40ddd65799097',
      'native_key' => 'universaleventbus',
      'filename' => 'modNamespace/77a4e122d0dbd783d846e55808f2757e.vehicle',
      'namespace' => 'universaleventbus',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7bf26867513c9a19c72333d29601dcfd',
      'native_key' => NULL,
      'filename' => 'modCategory/5b9e5572caad934882448dd66c8a7977.vehicle',
      'namespace' => 'universaleventbus',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4eada28c5d1fe372738e7be3ea843e17',
      'native_key' => NULL,
      'filename' => 'modCategory/09e8930cf04eaa2047ed7cd388a66737.vehicle',
      'namespace' => 'universaleventbus',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e35cafcf9a94d5c18d224d12df67319f',
      'native_key' => 'ueb_action_url',
      'filename' => 'modSystemSetting/eee28fd9f9757bb1dd4fc643a9b0c9de.vehicle',
      'namespace' => 'universaleventbus',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef26af18c624299d27c287790c26f34b',
      'native_key' => 'ueb_allowed_templates',
      'filename' => 'modSystemSetting/14449f386448e31476e33303fc452590.vehicle',
      'namespace' => 'universaleventbus',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e48e336a611b6eca17906566b7b16f00',
      'native_key' => 'ueb_autoload_path',
      'filename' => 'modSystemSetting/6ff9de8caed0464ab98b2565ab2f8914.vehicle',
      'namespace' => 'universaleventbus',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b6ef45ad72f2c9ab9fb3cbaf5153dab',
      'native_key' => 'ueb_cache',
      'filename' => 'modSystemSetting/def80c6c76af79c5b6fa559a96706e8f.vehicle',
      'namespace' => 'universaleventbus',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f37eee63f9e7de19b2349f5b1e11f13',
      'native_key' => 'ueb_close_classes',
      'filename' => 'modSystemSetting/ad9a4b17025952619dcfd4d423bf907c.vehicle',
      'namespace' => 'universaleventbus',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c20d8f89e38c7b84d424662a418d4d59',
      'native_key' => 'ueb_cursor_poll_initial',
      'filename' => 'modSystemSetting/6b91b3a1867952757cb2763533af661b.vehicle',
      'namespace' => 'universaleventbus',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdf5da964886a86157e561f7bb2d54ff',
      'native_key' => 'ueb_cursor_poll_max',
      'filename' => 'modSystemSetting/51fb99a3a699b9616935c7f01371c536.vehicle',
      'namespace' => 'universaleventbus',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f93d11d94674b8e247ea9f314bd26bf7',
      'native_key' => 'ueb_debug',
      'filename' => 'modSystemSetting/7dc5cb80c59b1549eb754456564a7ac2.vehicle',
      'namespace' => 'universaleventbus',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '477ad69e84b85f7b1f2cef4dc279936d',
      'native_key' => 'ueb_event_batch_size',
      'filename' => 'modSystemSetting/73255851882ea303e3071da5ba11553e.vehicle',
      'namespace' => 'universaleventbus',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'beadf41649ccb973f49d0e8eb79ccdc2',
      'native_key' => 'ueb_event_ttl',
      'filename' => 'modSystemSetting/bfbb989c5d96e8b624e4ea867fc4225f.vehicle',
      'namespace' => 'universaleventbus',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b3e50a0953007968c7a214986a5ccd2',
      'native_key' => 'ueb_frontend_js',
      'filename' => 'modSystemSetting/249372ea655c1e549512a881c29d8880.vehicle',
      'namespace' => 'universaleventbus',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72dce8e40540666f18eff16a407bf6ee',
      'native_key' => 'ueb_log_level',
      'filename' => 'modSystemSetting/80c50f2a07274abc43a916064095c91f.vehicle',
      'namespace' => 'universaleventbus',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd20217cabe533002de286797587329bd',
      'native_key' => 'ueb_navigation_timeout',
      'filename' => 'modSystemSetting/7b5c91c3b06361a12f7889fb349d2b47.vehicle',
      'namespace' => 'universaleventbus',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ceb55bea9058ecf669ec4dc680912fa8',
      'native_key' => 'ueb_open_classes',
      'filename' => 'modSystemSetting/2b15cc20272e6ceaaa2d10c368361294.vehicle',
      'namespace' => 'universaleventbus',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d85e2c56921eeb10787c5ce9c53f746',
      'native_key' => 'ueb_sse_handler_path',
      'filename' => 'modSystemSetting/7b3a0c10b606f8da7581ef2391981e64.vehicle',
      'namespace' => 'universaleventbus',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd92dc7966060f97cf58b6a12af2e072e',
      'native_key' => 'ueb_sse_retry',
      'filename' => 'modSystemSetting/9f096622ed07d614c9e4220f7f581514.vehicle',
      'namespace' => 'universaleventbus',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b18fb737e568e9ed646f5d0d49419eb',
      'native_key' => 'ueb_stream_duration',
      'filename' => 'modSystemSetting/79d520fa47b38effd8789323d7ec2c2f.vehicle',
      'namespace' => 'universaleventbus',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6a0f1b83c48610c3b63abfb908c14ff',
      'native_key' => 'ueb_stream_heartbeat',
      'filename' => 'modSystemSetting/0806b426f3ae8a592a07d0ca21a347dd.vehicle',
      'namespace' => 'universaleventbus',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f312568ccf614aa1dfd328a0ecf2f71a',
      'native_key' => 'ueb_stream_idle_timeout',
      'filename' => 'modSystemSetting/1be21d5c73d27f561bd63c94643c17eb.vehicle',
      'namespace' => 'universaleventbus',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8856cd68607525b4f9aa6635d1e764d2',
      'native_key' => 'ueb_stream_read_interval',
      'filename' => 'modSystemSetting/796e1740d808f0dc2e47a95fef375141.vehicle',
      'namespace' => 'universaleventbus',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed4019d3d737b5e577bb3d4fff905774',
      'native_key' => 'ueb_translit',
      'filename' => 'modSystemSetting/804840a15351ec6ff4d14a911424487b.vehicle',
      'namespace' => 'universaleventbus',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd34c4d571281e7677ded70e43949ba1',
      'native_key' => 'ueb_transport',
      'filename' => 'modSystemSetting/ab2663623a5128a4231262e401de70d6.vehicle',
      'namespace' => 'universaleventbus',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb3439dc3bdf37ca6561ab8edb60dd7e',
      'native_key' => 'OnUebInit',
      'filename' => 'modEvent/f08c0b3d47271fbffebfa0d5f3d30748.vehicle',
      'namespace' => 'universaleventbus',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c6a98e4182885061a539ce860bee8a2',
      'native_key' => 'OnBeforeUebHandleEvent',
      'filename' => 'modEvent/489da614a9aef07d150e55d05132bf37.vehicle',
      'namespace' => 'universaleventbus',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96a7cd118be59830cbe3234b07629db8',
      'native_key' => 'OnUebHandleEvent',
      'filename' => 'modEvent/5424e70b5c17e4d17b475d85ab093bb4.vehicle',
      'namespace' => 'universaleventbus',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c887069f49ed1845325255c2ba55adf',
      'native_key' => 'OnUebGetProductData',
      'filename' => 'modEvent/4fa733da5e0bd02d54287e27dc98d498.vehicle',
      'namespace' => 'universaleventbus',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b48580a4a75cd46c7a8995c24d74b648',
      'native_key' => 'OnUebGetPageData',
      'filename' => 'modEvent/f603b74d824b3a2d59ce4ad1e352faa8.vehicle',
      'namespace' => 'universaleventbus',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e6ad9f774eb9d64a6aa76aa4dc4e354',
      'native_key' => 'OnGetUebWebConfig',
      'filename' => 'modEvent/c6525058924aae4704b806f5576e679c.vehicle',
      'namespace' => 'universaleventbus',
    ),
  ),
);